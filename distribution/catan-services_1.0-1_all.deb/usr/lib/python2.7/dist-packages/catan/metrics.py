"""
    This file contains code to measure the performance of the system during operation
    
    @author: Ben Bullough    
"""

# Native
import os
import logging
logger = logging.getLogger(__name__)
import sqlite3
import json
import time
import re
import math

# CATAN
from catan.data import NodeMessage
import catan.db
import catan.globals as G

def log_database_counts(node_dict):
    #print "   Person ID per Node = " + str(node_dict)
    with open(G.METRICS_DBSYNC_LOG_FILENAME, 'a') as fh:
        fh.write("Time = %d, Nodes = %s\n" % ( int(round(time.time())), str(node_dict) ) )


def log_person_update(node_message):
    """
        This function takes a node message containing a person update and
        logs the communication delay based on the time encoded in the message

	called from catan_services
    """
    #print node_message, node_message.source, node_message.data
    db_obj = catan.db.CatanDatabaseObject(node_message.data)
    diff_time = None
    if db_obj.person_description:        
         if db_obj.person_description.person_description:
            description = db_obj.person_description.person_description   
            diff_time = extract_time_diff(description)
            msg_type = "Person"     
    elif db_obj.person_message:
        if db_obj.person_message.person_message:
            message = db_obj.person_message.person_message
            diff_time = extract_time_diff(message)
            msg_type = "Message"
            
    if diff_time:
        #print "Msg delay = %d" % diff_time
        with open(G.METRICS_UPDATE_LOG_FILENAME, 'a') as fh:
            fh.write("Time = %d, Delay = %d, Node = %d, Type = %s\n" % (int(round(time.time())), diff_time, node_message.source, msg_type ) )
            

def extract_time_diff(text):
    """
        Returns the difference between the current time and the time
        in the embedded << >> tag (encoded in POSIX time)
        or None if a matching tag cannot be found
    """

    time_list = re.findall('<<(.*)>>', text)
    if time_list:
        update_time = float(time_list[0])
        diff_time = round(time.time() - update_time)
        return diff_time
    else:
        return None
        
    
    
